#include "Enemy.h"
void Enemy::Update(){
}
void Enemy::Draw(){
}